This is the template file set for template Vital signs( 74b50979-ab22-4351-bfdc-cc5191ea0ac5, revision 1), exported from the Clinical Knowledge Manager.

Export time: Fri May 29 18:08:54 CEST 2026